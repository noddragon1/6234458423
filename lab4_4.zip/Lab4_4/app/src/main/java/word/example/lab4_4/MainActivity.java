package word.example.lab4_4;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    static String year, easterDays;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText easter1 = findViewById(R.id.inputYear);
        Button check = findViewById(R.id.enter);

        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                year = easter1.getText().toString();

                if(year.length()!=0) {
                    int num = Integer.parseInt(year);

                    EasterSunday1 easter = new EasterSunday1(num);
                    easterDays =  easter.examine();
                    startActivity(new Intent(MainActivity.this, EasterSunday2.class));
                }

            }
        });


    }

}