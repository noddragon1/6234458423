/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_2;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author acer
 */
public class Game {
  private int player,computer,funGame = 0;         
  
public void play(){           
           while(funGame==0){             
                      System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
                      Scanner choose = new Scanner(System.in); 
                      int play = choose.nextInt();
                      if(play == 0 || play==1|| play==2){
                      if(play == 0){System.out.println("You enter: ROCK");}
                      else if(play == 1){System.out.println("You enter: PAPER");}
                      else{System.out.println("You enter: SCISSORS");}
          
                      Random com = new Random();
                      int bot = com.nextInt(3);
                      if(bot == 0){System.out.println("Computer: ROCK");}
                      else if(bot == 1){System.out.println("Computer: PAPER");}
                      else{System.out.println("Computer: SCISSORS");}
                      if(play==0&&bot==0){}
                      else if(play==bot){System.out.println("It's a tie.");}
                      else if(play==0&&bot==1){System.out.println("You lose!");computer++;}
                      else if(play==0&&bot==2){System.out.println("You win!");player++;}
                      else if(play==1&&bot==0){System.out.println("You win!");player++;}
                      else if(play==1&&bot==2){System.out.println("You lose!");computer++;}
                      else if(play==2&&bot==0){System.out.println("You lose!");computer++;}
                      else if(play==2&&bot==1){System.out.println("You win!");player++;}                                                   
                      if(player-computer ==2||computer-player==2){funGame++;}           
                                 } 
                     }
           if(player>computer){
               System.out.println("Congrats! You win.");
               System.out.println("User Score: "+player);
               System.out.println("Computer score: "+computer);
                     }
           if(player<computer){
               System.out.println("Too bad! You lose.");
               System.out.println("User Score: "+player);
               System.out.println("Computer score: "+computer);
                      }
           
           }
}
       
       
       
       
       
    

