/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_1;

/**
 *
 * @author acer
 */
public class Subject implements Evalution{
     private String subjName;
    private int[] score;
    
    public Subject(String subject_name, int[] scoreSj){
        subjName = subject_name;
        score = scoreSj;
    }
    
    @Override
    public double evaluate(){
        int total=0;
        for(int i=0; i<score.length; i++){
            total+=score[i];
        }
        double average = total/score.length;
        return average;
    }
    
    @Override
    public char grade(double g){
        g = evaluate();
        if(g>=70){
            return 'P';
        }
        else{
            return 'F';
        }
    }
    
    @Override
    public String toString(){
        return subjName;
    }
    
}
