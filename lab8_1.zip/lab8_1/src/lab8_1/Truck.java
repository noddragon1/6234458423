/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_1;

/**
 *
 * @author acer
 */
public class Truck extends Car {
    private double M_weight,weight;
    
 public Truck(double gas,double efficiency,double M_weight,double weight){
           super(gas,efficiency);
           if(weight > M_weight){
                this.weight = M_weight;
          }
            else{
                this.M_weight = M_weight;
                this.weight = weight;
           }
   } 

 public void drive(double distance){
      if(weight<1){super.drive(distance);}
      else if(weight<11){super.drive(distance*1.1);} 
     else if(weight<20||weight==20){super.drive(distance*1.2);} 
      else{super.drive(distance*1.3);} 
   } 
}
