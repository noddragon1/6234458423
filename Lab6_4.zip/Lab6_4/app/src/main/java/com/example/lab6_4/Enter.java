package com.example.lab6_4;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.sax.StartElementListener;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class Enter extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.enter);
        final Button guess = findViewById(R.id.guess);
        final EditText enter = findViewById(R.id.enter);
        final TextView out = findViewById(R.id.out);
        final Game game = new Game();
        guess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String check = enter.getText().toString();
                if (check.length() <= 3 && check.length() != 0) {
                    int num = Integer.parseInt(check);
                    String a = game.Guess(num);
                    out.setText(a);
                    if (a == "You won") {
                        startActivity(new Intent(Enter.this, won.class));
                        enter.setText("");
                        finish();
                    } else {
                        out.setText(a);
                        enter.setText("");
                    }
                }
            }
        });
    }
}