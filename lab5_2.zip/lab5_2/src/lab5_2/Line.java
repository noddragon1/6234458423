/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_2;

import java.awt.geom.Point2D;
import static java.lang.Double.NaN;

/**
 *
 * @author acer
 */
public class Line {
     private double x;
     private double m;
     private double b;
     
     
     public Line(double x, double y, double m){
       this.m = m;
       this.x =x;
       this.b = y-(m*x);
       this.m = NaN;
           }
        
     public Line(double x1, double y1, double x2, double y2){
         double ms = (y2-y1)/(x2-x1);
         double bs = y1-(ms*x1);
         this.m = ms;
         this.b = bs;
         this.x = NaN;
          }
     
     public Line(double m, double b){
            this.m = m; 
            this.b = b;         
            this.x = NaN;         
         }
     
     
     
     public Line(double a) {
          this.x = a;
          this.m = NaN;
          this.b = NaN;         
         }
        
     public boolean isParallel(Line line){
             return this.m == line.m;
         }
     
     
     public boolean equals(Line line){
             return(this.m == line.m &&this.b == line.b);        
         }
     
     
     public boolean isIntersect(Line line){
         boolean isIntersect = true;
         if (this.m==line.m){
               isIntersect = false;
             }
         return isIntersect;
         } 
     
     
     public Point2D.Double getIntersectionPoint(Line line){
         double x,y;
         if(Double.isNaN(this.m)){
         x = this.x;
         y=this.m*x+this.b;
         }
         else if(Double.isNaN(line.m)){
          x = line.x;
          y = line.m*x+line.b;
            }
         else{    
           x = (line.b-this.b)/(this.m-line.m);
           y = this.m*x+this.b;
         }
      return new Point2D.Double(x,y);
     }
}

