/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package letter;

public class Letter{
   private String name;
   private String recieve;
   private String newText;
    public Letter(String from, String to){
        name = from;
        recieve = to;        
        newText = "";
    }    
    public void addLine(String line){
        newText = newText+line+"\n";
    }    
    public String getText(){    
        return "Dear "+recieve+":"+"\n\n"+newText+"\n"+"Sincerely,"+"\n\n"+name;
        
    }
}    
    
    
