/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package letter;


public class LetterPrinter {
   public static void main(String[] args){
    Letter name = new Letter("nan","nod");
    name.addLine("you are very handsome");
    name.addLine("I like you");
    System.out.println(name.getText());
   }
}
