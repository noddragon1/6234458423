/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_2;

/**
 *
 * @author acer
 */
public class Question {
    private String text,answer;
    public Question(){
    
      }
    public Question(String x){
        this.text = x;
    }
    public void setText(String x){
     this.text = x;
    }
     public void setAnswer(String x){
     this.answer =x;
    }
      public  String getText(){
     return text;
    }
       public String getAnswer(){
    return answer;
    }
    public  boolean checkAnswer(String response){
       return response.equals(answer);
       }
   public void display(){
        System.out.println(text);  
   }

}            

