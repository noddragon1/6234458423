
import java.awt.Rectangle;
import java.util.Random;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author usci
 */
public class IntersectionPrinter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Random rad = new Random();
        int x = rad.nextInt(50);  x+=1;
        int y = rad.nextInt(50); y+=1;
        int width = rad.nextInt(50); width+=1;
        int height = rad.nextInt(50); height+=1;
        Rectangle r1 = new Rectangle(x,y,width,height);       
        x = rad.nextInt(50);  x+=1;
        y = rad.nextInt(50); y+=1;
        width = rad.nextInt(50); width+=1;
        height = rad.nextInt(50); height+=1;
        Rectangle r2 = new Rectangle(x,y,width,height);
        System.out.println(r1);
        System.out.println(r2);
        Rectangle r3 = r1.intersection(r2);
        System.out.println("Is the intersected rectangle empty? :"+r3.isEmpty());
        
        
       
        
    }
    
}
