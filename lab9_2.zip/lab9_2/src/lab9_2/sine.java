/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_2;

/**
 *
 * @author acer
 */
public class sine extends Taylor{
   public sine(int k,double x){
  super(k,x);  
  }   
    public  double getApprox(){
    double result = 0;
    for(int n=0;n<=super.getIter();n++){
        result+=Math.pow(super.getValue(),(2*n)+1)*Math.pow(-1,n)/super.factorial((2*n)+1);
} 
    return result;
    } 
public void printValue(){
    System.out.println("Value from Math.exp() is "+Math.sin(super.getValue())+".");
    System.out.println("Approximated value is "+getApprox()+".");
   }
}
