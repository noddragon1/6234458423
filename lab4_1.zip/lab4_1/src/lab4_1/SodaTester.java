/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_1;

import java.util.Scanner;

/**
 *
 * @author usci
 */
public class SodaTester {
    public static void main(String[] args) {
      Scanner can = new Scanner(System.in);
      System.out.println("Enter height: ");
      double height = can.nextDouble();
      System.out.println("Enter diameter: ");
      double diameter = can.nextDouble();
       
      
      SodaCan can1 = new SodaCan(height,diameter);
      System.out.println("Volume:"+can1.getVolume());
      System.out.println("Surface area:"+can1.getSurfaceArea());
               
    }
}
