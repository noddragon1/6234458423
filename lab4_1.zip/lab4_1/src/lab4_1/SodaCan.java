/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_1;

import static java.lang.Math.PI;
import static java.lang.Math.pow;

/**
 *
 * @author usci
 */
public class SodaCan {
    
    private double height ;
    private double diameter;
    
public SodaCan(double heights,double diameters){
    height = heights;  
    diameter = diameters;
}
public double getVolume(){ 
    double rad = diameter/2;
    double rad2 = pow(rad,2);
    double volume = PI*rad2*height; 
    volume = Math.round(volume*100)/100.0; 
    return volume;
}
public double getSurfaceArea(){ 
    double rad = diameter/2;
    double rad2 = pow(rad,2);
    double surface = (2*PI*rad*height)+(2*PI*rad2);
    surface = Math.round(surface*100)/100.0;
    return surface;
}


}
