/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_3;

/**
 *
 * @author acer
 */
public class CashRegister {
     private double tax;
     private double taxRate;
     private double total;
     private double payment;
public CashRegister(double taxRate){
    this.taxRate = taxRate/100;
           }
public void RecordPurchase(double price){
    total = total+price; 
           }
public void RecordTaxablePurchase(double price){
    total = total+price;
    tax = tax+price*taxRate;
           }        
public double GetTotalTax(){
       return tax;
           }
public void EnterPayment(double pay){
    payment = payment+pay; 
           }
public double GiveChange(){
        double changes = payment-(total+tax);
        total = 0;
        tax = 0;
        payment = 0;
        return changes;
           }
}
    
    
    

