/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_3;



/**
 *
 * @author acer
 */
public class CashRegisterTester {
     public static void main(String[] args){
       CashRegister cash = new CashRegister(7);
       cash.RecordPurchase(50);
       cash.RecordPurchase(10);
       cash.RecordTaxablePurchase(20);
       cash.EnterPayment(100);
       System.out.printf("Your change is "+"%.1f\n",cash.GiveChange());
       
   }
}
