/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_3;

import java.util.Random;

/**
 *
 * @author acer
 */
public class CityGrid {
    private int xCoor; //เก็บพิกัดของชายผู้หนึ่งในแนวแกน x
    private int yCoor; //เก็บพิกัดของชายผู้หนึ่งในแนวแกน y
    private final int gridSize; //เก็บขนาดของเมือง
    private final int x;
    private final int y;
    public CityGrid(int x,int y){
       this.x =x;
       this.y = y; 
       this.xCoor = x/2;
       this.yCoor = y/2;
       this.gridSize = x*y;  
    }
    public void walk(){
        Random ran = new Random();
       int walk = ran.nextInt(4);
       switch(walk){
           case 0 : xCoor++;break;  
           case 1 : xCoor--;break;
           case 2 : yCoor++;break;
           case 3 : yCoor--;break;
             }          
         }
      public boolean isInCity(){
           
          if(xCoor<0||xCoor>x||yCoor<0||yCoor>y){
              return false;
           }   
         return true;
           }
        public void reset(){
            xCoor = x/2;
            yCoor = y/2;
        }
        
    }
    
    
    
    

