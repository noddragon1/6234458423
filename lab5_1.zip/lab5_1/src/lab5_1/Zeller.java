/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_1;

/**
 *
 * @author acer
 */
public class Zeller {
  
    private final int dayOfMonth;
   private final int month;
   private final int year;
 
   
   private enum Day{
      SUNDAY("Sunday"), MONDAY("Monday"), TUESDAY("Tuesday"), WEDNESDAY("Wednesday"), THURSDAY("Thursday"), FRIDAY("Friday"), SATURDAY("Saturday");
    public final String days;
    
    Day(String dayName){
       this.days = dayName; 
        }
  
    public String dayName(){
           return days;
      }
       
   }
 
   public Zeller(int dayOfMonths,int month,int years){
     dayOfMonth = dayOfMonths;
    switch(month){
         case 1: this.month =13;year =years-1;break; 
         case 2: this.month =13;year =years-1;break;
         default: this.month = month;year =years;
     }
  }
   
   public Day getDayOfWeek(){
       int h = (dayOfMonth+26*(month+1)/10+((year%100)*5)/4+(21*(year/100))/4)%7;
        Day days;
        switch (h) {
            case 0: days = Day.SATURDAY; break;
            case 1: days = Day.SUNDAY; break;
            case 2: days = Day.MONDAY; break;
            case 3: days = Day.TUESDAY; break;
            case 4: days = Day.WEDNESDAY; break;
            case 5: days  = Day.THURSDAY; break;
            case 6: days  = Day.FRIDAY; break;
            default:days  = null; 
        }
        return days ;
   }
           
   
   
   
   
   }
   
   
   
   
   
   
