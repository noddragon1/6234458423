/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_3;

/**
 *
 * @author acer
 */
public class TimeInterval {
   private  int start;
   private int end;
 
public TimeInterval(int starts,int ends){    
    start = starts;
    end = ends;
       
}
public int getHours(){
    int mathstart = (((start/100)*60)+(start%100));
    int mathstop = (((end/100)*60)+(end%100));
    int hour = (mathstop-mathstart)/60;
     return hour ;
}
public int getMinutes(){
    int mathstart = (((start/100)*60)+(start%100));
    int mathstop = (((end/100)*60)+(end%100));
    int minute =  (mathstop-mathstart)%60;
    return minute;
   }


}
