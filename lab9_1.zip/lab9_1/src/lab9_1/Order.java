/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_1;

import java.util.ArrayList;

/**
 *
 * @author acer
 */
public class Order {
 public static int cntOrder = 0; //ตัวนี้เอาไว้ auto generate id ของใบ order
 private int id;
 private Customer c;
 private ArrayList<Pizza> p =  new ArrayList<>();
 public Order(Customer x){
        this.c = x;
        cntOrder++;
      }
 public void addPizza(Pizza p){
    this.p.add(p);
    }
 public String getOrderDetail(){
     id = cntOrder; 
     String order="Order id : "+id+"\n"+c.toString()+"\n";
        for(Pizza pizza:p){
            order+=pizza.toString()+"\n";
        }
        order+="Total pieces : "+p.size()+"\n"+"Total cost : "+calculatePayment();
        return order;

     }
 public double calculatePayment(){
      double revenue=0;

        for(int i=0;i<p.size();i++){
            revenue+=p.get(i).getPrice()*(1-c.getDiscount());
            cntOrder=0;
        }
        return revenue;
     }
 }
