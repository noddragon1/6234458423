/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_1;

import java.util.ArrayList;

/**
 *
 * @author acer
 */
public class MusicBox implements SimpleQueue{
     ArrayList<String> music = new ArrayList<>();
 @Override   
    public void enqueue(Object o){
         String song = (String) o;
          music.add(song);
          System.out.println(song+" is added in queue.");
    }
    @Override
    public  void dequeue(){
       System.out.println("Now playing "+music.get(0));
       music.remove(0);
    }
}
