/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_1;

import java.util.ArrayList;

/**
 *
 * @author acer
 */
public class SelfCheckOut implements SimpleQueue{
  ArrayList<Product> products = new ArrayList<>();
    private double total;
    
    public SelfCheckOut() {
        total = 0;
    }
    
      @Override
      public void enqueue(Object o) {
          Product item = (Product) o;
          products.add(item);
          System.out.println(item.getName()+" is added in queue.");
      }
      @Override
      public void dequeue() {
          
          total += products.get(0).getPrice();
          products.remove(0);
      }
      public double getAmount() {
          return total;
      }
}
