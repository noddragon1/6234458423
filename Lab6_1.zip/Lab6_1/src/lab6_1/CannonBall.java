/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_1;

/**
 *
 * @author acer
 */
public class CannonBall {
private double initV; 
    private double simS; 
    private double simT; 
    public static final double g = 9.81;
   
    public CannonBall(int v)
    {
        initV = v;
    }
    public void simulatedFlight()
    {
        double delT = 0.01;
        double v = initV;
        double delS;
        int time = 0;
        int second = 1;
 
        while (v > 0)
            {
                delS = v * delT;
                v = v - (g*delT);
                simS = simS + delS;
                simT = simT + delT;
                time = time+1;
               
                if (time == 100)
                {
                    System.out.printf("Distance on %d sec: %.3f", second,simS );
                    System.out.println();
                    time = 0;
                    second += 1;    
                }
            }
    }
   
    public double calculusFlight(double t)//s(t) = -0.5*g*t2 + v0*t
    {
        double s = (-0.5)*g*Math.pow(t, 2) + initV*t;
        System.out.printf("Final distance: %.3f Total time: %.2f" , simS,simT );
        System.out.println();
        return Math.round(s*1000)/1000.000;
    }
   
    public double getSimulatedTime()
    {
        return simT;
    }
   
    public double getSimulatedDistance()
    {
        return simS;
    }
}
    

